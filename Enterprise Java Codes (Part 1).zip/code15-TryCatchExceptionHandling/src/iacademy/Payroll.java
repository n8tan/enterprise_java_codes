package iacademy;

public class Payroll {
	
		private double hoursWorked;
		private double ratePerHour;
		private double grossPay;
		
		public void computeSalary() {
			grossPay = hoursWorked * ratePerHour;
		}
		
		public double getHoursWorked() {
			return hoursWorked;
		}

		public void setHoursWorked(double hoursWorked) {
			if (hoursWorked > 60 || hoursWorked < 0) {
				throw new IllegalArgumentException();
			} else {
				this.hoursWorked = hoursWorked;
			}
			
		}

		public double getRatePerHour() {
			return ratePerHour;
		}

		public void setRatePerHour(double ratePerHour) {
			if (ratePerHour < 0) {
				throw new RuntimeException();
			} else {
				this.hoursWorked = hoursWorked;
			}
			this.ratePerHour = ratePerHour;
		}

		public double getGrossPay() {
			return grossPay;
		}

		public void setGrossPay(double grossPay) {
			this.grossPay = grossPay;
		}
}
