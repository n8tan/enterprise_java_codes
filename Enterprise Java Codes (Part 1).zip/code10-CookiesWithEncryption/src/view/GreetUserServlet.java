package view;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import utility.CookieHelper;
import utility.Security;
@WebServlet("/greetuser.html")
public class GreetUserServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		
		PrintWriter out = response.getWriter();
		
		Cookie userCookie = CookieHelper.getCookie(request.getCookies());
		

		
		if(userCookie != null) {
			out.print("<html>");
			out.print(" <head><title>Greetings</title></head>");
			out.print(" <body>");
			
			out.print("<h2>Welcome, "+ Security.decrypt(userCookie.getValue()) + "</h2>");
			out.print("<p>Please click <a href = 'logout.html'>here</a> to logout.</p>");
			out.print("</body>");
			out.print("</html>");
		} else {
			response.sendRedirect("index.html");
		}

		
		
	}

}
