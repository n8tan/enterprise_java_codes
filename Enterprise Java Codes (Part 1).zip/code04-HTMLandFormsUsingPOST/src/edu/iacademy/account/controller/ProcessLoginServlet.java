package edu.iacademy.account.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class ProcessLoginServlet
 */
@WebServlet("/processLogin.html")
public class ProcessLoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		
		PrintWriter out = response.getWriter();
		
		//get the input value
		String name = null;
		String password = null;
		
		if(request.getParameter("userID") != null) {
			name = request.getParameter("userID");
		}
			
		if(request.getParameter("userPassword") != null) {
			password = request.getParameter("userPassword");
		}
			
		out.print("<html>");
		out.print("<body>");
		
		if(checkUserAccount(name, password)) {
			out.print(" <h1>Hello, " + name + "</h1>");
		} else {
			out.print(" <h2><font color='red'>Invalid Account entered. "
			+ "Please click <a href= 'index.html'>here</a> to try again.</font></h2>");
			
		}
		out.print("<hr/>");
		out.print("<p><i>programmed by Nathan Remante</i></p>");
		out.print("</body>");
		out.print("</html>");
		out.close();
	}
	
	public boolean checkUserAccount(String name, String password) {
		return (((name.equals("dirk@nowitzki.com") && password.equals("mvpD1RK")))
				|| (( name.equals("user") && password.equals("123")))
				?true
				:false);
	}
}
