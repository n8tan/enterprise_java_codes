package com.test;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


//@WebServlet(description = "This Servlet displays the Hello World on a web page.", urlPatterns = { "/index.html" })
public class HelloWorldServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public void init(ServletConfig config) throws ServletException {
		super.init(config);
		System.out.println("init method called from " + config.getInitParameter("iskul"));
	}
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.setContentType("text/html");
		
		PrintWriter out = response.getWriter();
		
		out.print("<html>");
		out.print("<body>");
		out.print("	<h1>Hello World using Java Servlet</h1>");
		out.print("	<h2>I love Java Servlet programming</h2>");
		out.print("	<hr/>");
		out.print("	<p><i>programmed by Mon Zalameda</i></p>");
		out.print("<p>" + new java.util.Date() +  getServletConfig().getInitParameter("iskul")+"</p>");
		out.print("</body>");
		out.print("</html>");
		
		out.close();
	}
	
	public void destroy() {
		System.out.println("destroy method called.");
	}

}
