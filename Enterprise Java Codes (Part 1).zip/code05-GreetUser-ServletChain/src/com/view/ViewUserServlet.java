package com.view;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.omg.CORBA.portable.ResponseHandler;

import com.model.User;

@WebServlet("/viewuser.html")
public class ViewUserServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.setContentType("text/html");
		
		PrintWriter out = response.getWriter();
		
		
		User user = null;
		
		RequestDispatcher dispatch = null;
		
		if (request.getAttribute("userDetails" ) != null) {
			user = (User)request.getAttribute("userDetails");
		}
		
		//get the attribute
		
		
		out.print("<!DOCTYPE html>");
		out.print("<html>");
		out.print("<body>");
		
		dispatch = request.getRequestDispatcher("header-design/header.html");
		out.print("<header>");
		dispatch.include(request, response);
		out.print("</header>");
		
		if (user == null) {
			out.print(" <h2><font color='red'>Invalid Account entered. "
			+ "Please click <a href= 'index.html'>here</a> to try again.</font></h2>");
		} else {
			out.print("<h2>Hello, " + user.getName() + "</h2>");
			out.print("<h2>Your age is " + user.getAge() + "</h2>");
			out.print("<h2>Your age 5 years from now is " + (user.getAge() +5) + "</h2>");
		}
		
		out.print("<hr/>");
		
		out.print("<form action='index.html'>");
		out.print(" <input type='submit' value=' << GO BACK >>'/>");
		out.print("</form>");
		
		dispatch = request.getRequestDispatcher("footer-design/footer.html");
		out.print("<footer>");
		dispatch.include(request, response);
		out.print("</footer>");

		out.print("</body>");
		out.print("</html>");
		out.close();
	}

}
