package view;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;



@WebServlet("/greetuser.html")
public class GreetUserServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {	
		
		HttpSession session = request.getSession(false);
		
		//checks if the user is INVALID and if trying to access this page directly 
		//without logging-in
		if(session != null) {
			response.setContentType("text/html");
			
			PrintWriter out = response.getWriter();
			
			out.print("<html>");
			out.print("	<head><title>Greetings</title></head>");
			out.print("	<body>");
			
			out.print("<h2>Welcome, " + (String) session.getAttribute("user") + "</h2>");
			out.print("<h2>Assigned Session ID:" + session.getId() + "</h2>");
			out.print("<p>Please click <a href='logout.html'>here</a> to logout.</p>");
			out.print("</body>");
			out.print("</html>");
			out.close();
			
		} else {
			response.sendRedirect("index.html");
		}
	
	}
}
