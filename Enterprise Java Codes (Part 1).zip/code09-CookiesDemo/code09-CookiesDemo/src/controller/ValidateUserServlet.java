package controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/validateuser.html")
public class ValidateUserServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		String userName = request.getParameter("userName");
		String password = request.getParameter("userPassword");
		
		if(isUserValidate(userName, password)){
			//now create a cookie if user is valid 
			Cookie userCookie = new Cookie("user", userName);
			
			//set cookie to expire in 5 years
			userCookie.setMaxAge(5 * 365 * 24 * 60 * 60);
			
			//now send the cookie to the user
			response.addCookie(userCookie);
			response.getWriter().print("Successfully created cookie." 
			+ "Click <html><body><a href='greetuser.html'>here</a></body></html>");
			
		}else{ //means that user input is invalid
			response.sendRedirect("index.html");
		}
	}

	public boolean isUserValidate(String name, String password){
		return (name.equals("user") 
				&& password.equals("1234") 
				?true 
				:false
		);
	}
}
