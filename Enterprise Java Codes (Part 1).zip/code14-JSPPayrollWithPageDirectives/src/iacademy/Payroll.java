package iacademy;

public class Payroll {
	
		public double hoursWorked;
		public double ratePerHour;
		public double grossPay;
		
		public void computeSalary() {
			grossPay = hoursWorked * ratePerHour;
		}
	
}
