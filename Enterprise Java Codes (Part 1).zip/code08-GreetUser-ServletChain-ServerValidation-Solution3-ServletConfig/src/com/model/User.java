package com.model;

public class User {
	
	private String name;
	private int age;
	private int ageFiveYearsFromNow;
	
	public User() {
		
	}
	
	public User(String name, int age, int age5Plus) {
		setName(name);
		setAge(age);
		setAgeFiveYearsFromNow(age5Plus);
	}
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		if(age <= 0 || age > 115) {
			throw new IllegalArgumentException();
		} else {
			this.age = age;
		}
		
	}
	
	public int getAgeFiveYearsFromNow() {
		return ageFiveYearsFromNow;
	}

	public void setAgeFiveYearsFromNow(int ageFiveYearsFromNow) {
		this.ageFiveYearsFromNow = ageFiveYearsFromNow + getAge();
	}
}
