package com.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.model.User;

public class ProcessGreetServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	public String programmer;
	int age5Plus;
	
	public void init() throws ServletException{
		age5Plus = Integer.parseInt(getServletConfig().getInitParameter("age5"));
		programmer = getServletConfig().getInitParameter("programmer");
		
		getServletContext().log("Successfully retrieved servlet init paramters.");
	}
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String name = request.getParameter("userName");
		int age;
		
			age = Integer.parseInt(request.getParameter("userAge"));
			//now create a bean instance and set the values
			User user = new User(name, age, age5Plus);
			
			//now store the user object in the request object
			request.setAttribute("userDetails", user);
			getServletContext().setAttribute("tagaCode", programmer);
			//create a RequestDispatcher object
			//and forward the result to another servlet
			request.getRequestDispatcher("viewuser.html").forward(request, response);
	
	}

}
