package erdbms.controller;

import java.util.Date;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import erdbms.sample.model.Employee;

public class TestHibernate {

	public static void main(String[] args) {
		Employee employee1 = new Employee();

		employee1.setId(1);
		employee1.setLastName("Nowitzki");
		employee1.setFirstName("Dirk");
		employee1.setPosition("rebounding");
		employee1.setDepartment("Mavericks");
		employee1.setAddress("Dallas, Texas");
		employee1.setJoinedDate(new Date());
		employee1.setDescription("premiere power forward");
		
		Employee employee2 = new Employee();
		employee2.setId(2);
        employee2.setLastName("Nowitzki2");
        employee2.setFirstName("Dirk2");
		employee2.setPosition("rebounding2");
		employee2.setDepartment("Mavericks2");
		employee2.setAddress("Dallas, Texas2");
		employee2.setJoinedDate(new Date());
		employee2.setDescription("premiere power forward2");
		
		Employee employee3 = new Employee();
		employee3.setId(3);
        employee3.setLastName("Curry");
        employee3.setFirstName("Stephen");
		employee3.setPosition("assist");
		employee3.setDepartment("future Mavericks");
		employee3.setAddress("Dallas, Texas2");
		employee3.setJoinedDate(new Date());
		employee3.setDescription("premiere point guard");
		
		//open the configuration file to create a SessionFactory object
		SessionFactory sessionFactory = 
			new Configuration().configure().buildSessionFactory();
		
		Session session = sessionFactory.openSession();
		session.beginTransaction();
		session.save(employee1);
		session.save(employee2);
		session.save(employee3);
		session.getTransaction().commit();
		
		//newly added code
		session.close();
		
		/***** DATA OBJECT Retrieval ****/
		//make employee as null - 
		//this will be our placeholder once we retrieve the data
		Employee employee = null;
		
		//sessionFactory is created once per application. it does not close.
		
		session = sessionFactory.openSession();
		session.beginTransaction();
		
		employee = 
			(Employee) session.get(
				erdbms.sample.model.Employee.class, 3);
		
		displayEmployeeDetails(employee);
		
	}
	
	public static void displayEmployeeDetails(Employee emp) {
		System.out.println("ID: " + emp.getId());
		System.out.println("Name: " + emp.getLastName() + ", " 
				+ emp.getFirstName());
		System.out.println("Position: " + emp.getPosition());
		System.out.println("Department: " 
			+ emp.getDepartment());
		System.out.println("Description: " 
				+ emp.getDescription());
	}

}
