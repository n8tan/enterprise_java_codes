package erdbms.sample.model;

import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

//Discussion Points: Entity object and value object

/*
 Entity object - a type of object that needs to be saved
  in a separate table in the database. 
  It contains data that provides meaning by itself.  
 
 Value object - an object that has data and even that has 
 to be saved in the database but it does not provide 
 the meaning by itself but provides meaning to other objects.
 
 */
@Entity
@Table (name = "Employee_Details" )
public class Employee {
	//strategy
	@Id @GeneratedValue
	private int id;
	private String lastName;
	private String firstName;
	private String position;
	private String department;
	
	@Embedded
	private Address address;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getPosition() {
		return position;
	}
	public void setPosition(String position) {
		this.position = position;
	}
	public String getDepartment() {
		return department;
	}
	public void setDepartment(String department) {
		this.department = department;
	}
	public Address getAddress() {
		return address;
	}
	public void setAddress(Address address) {
		this.address = address;
	}
}
