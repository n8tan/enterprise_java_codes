package erdbms.controller;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import erdbms.sample.model.Employee;
import erdbms.sample.model.Address;

public class TestHibernate {
	
	public static void main(String[] args) {
		Employee employee1 = new Employee();
		employee1.setLastName("Nowitzki");
		employee1.setFirstName("Dirk");
		employee1.setPosition("rebounding");
		employee1.setDepartment("Mavericks");	
		
		Address address1 = new Address();
		address1.setStreet("Dallas");
		address1.setCity("Texas");
		employee1.setAddress(address1);
		
		Employee employee2 = new Employee();
		employee2.setLastName("Jordan");
		employee2.setFirstName("Michael");
		employee2.setPosition("shooting");
		employee2.setDepartment("Bulls");
		
		Address address2 = new Address();
		address2.setStreet("Chicago");
		address2.setCity("Illinois");
		employee2.setAddress(address2);
		
		//open the configuration file to create a SessionFactory object
		SessionFactory sessionFactory = 
			new Configuration().configure().buildSessionFactory();
		
		Session session = sessionFactory.openSession();
		session.beginTransaction();
		session.save(employee1);
		session.save(employee2);
		session.getTransaction().commit();
		
		//newly added code
		session.close();		
	}
}
