package meralco.controller;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;


import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class ListCustomerServlet
 */

public class ListCustomerServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	Connection connection = null;
	
    public ListCustomerServlet() {
        super();
        
    }

	
	public void init() throws ServletException {
		
		try {
			Class.forName(getServletContext().getInitParameter("dbDriverName"));
			
			StringBuffer dbConfig = 
				new StringBuffer("jdbc:")
				.append(getServletContext().getInitParameter("dbType"))
				.append("://")
				.append(getServletContext().getInitParameter("dbServerName"))
				.append(":")
				.append(getServletContext().getInitParameter("dbPort"))
				.append("/")
				.append(getServletContext().getInitParameter("dbDatabase"));
					
			connection = DriverManager
				.getConnection(dbConfig.toString(), 
						getServletContext().getInitParameter("dbUserName"),
						getServletContext().getInitParameter("dbPassword"));
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
			return;
		} catch (SQLException sqle) {
			System.err.println("SQLE - " + sqle.getMessage());
			sqle.printStackTrace();
		}	
	}

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
			
			if (connection != null) {
				System.out.println("Successful connection");
				Statement stmt = connection.createStatement();
				ResultSet customerRS = stmt.executeQuery("select * from meralcocustomer");
				
				request.setAttribute("dbRecord", customerRS);
				request.getRequestDispatcher("listcustomers.jsp").forward(request, response);
				
			} else {
				response.sendRedirect("error.jsp");
			}
			
		} catch (SQLException sqle) {
			response.sendRedirect("error.jsp");
		}
	}

}
