package meralco.model;

import com.opensymphony.xwork2.ActionSupport;
import java.sql.*;

import meralco.utility.Rates;

//1st step - define beans to represent the data
public class Customer extends ActionSupport implements Rates {



	private CustomerBean customerBean = new CustomerBean();
	
	private boolean isError = false;
	public String execute() {
	
		customerBean.process();
		System.out.println("Last name: " + customerBean.getLastName());
		System.out.println("First name: " + customerBean.getFirstName());
		System.out.println("Hours Consumed: " + customerBean.getHours());
		System.out.println("Basic Charge Amount: Php" + customerBean.getBasicChargeAmount());
		System.out.println("Excess Charge Amount: Php" + customerBean.getExcessChargeAmount());
		System.out.println("VAT Amount: Php" + customerBean.getTaxVatAmount());
		System.out.println("Total Payable Amount: Php" + customerBean.getTotalChargeAmount());
		
		if(isError){
			return ERROR;
		}else {
			return SUCCESS;
		}
		
	}
	
	public void validate() {
		if(customerBean.getLastName().trim().length()==0) {
			addFieldError("customerBean.lastName", "Missing lastname entry.");
		}
		if(customerBean.getFirstName().trim().length()==0) {
			addFieldError("customerBean.firstName", "Missing firstname entry.");
		}
		if(customerBean.getHours() <= 0 ) {
			addFieldError("customerBean.hours", "Invalid value entered.");
		}
	}
	
	public CustomerBean getCustomerBean() {
		return customerBean;
	}

	public void setCustomerBean(CustomerBean customerBean) {
		this.customerBean = customerBean;
	}
}
