package meralco;

public class Payment implements ElectricRates {
	
	private double inputHours;
	private double basicCharge;
	private double excessCharge;
	private double vatCharge;
	private double total;
	
	public double getInputHours() {
		return inputHours;
	}
	
	public void setInputHours(double inputHours) {
		this.inputHours = inputHours;
	}
	
	public double computeBasicCharge(){
		double computedBasic = 0.0;
		if(this.inputHours < 250) {
			computedBasic = (this.inputHours * MIN_RATES);
		} else {
			computedBasic = 1550;
		}
		this.basicCharge = computedBasic;
		return computedBasic;
	}
	
	public double computeExcessCharge(){
		double computedExcess = 0.0;
		if(this.inputHours >= 250) {
			computedExcess = ((this.inputHours-250) * MAX_RATES);
		}
		this.excessCharge = computedExcess;
		return computedExcess;
		
	}
	
	public double computeVatCharge(){
		double computedVat = 0.0;
		computedVat = (this.basicCharge + this.excessCharge) * TAX_RATE;
		
		this.vatCharge = computedVat;
		return computedVat;
	}
	
	public void computeTotal(){
		double basicAmount = computeBasicCharge();
		double excessAmount = computeExcessCharge();
		double vatAmount = computeVatCharge();
		
		this.total = (basicAmount + excessAmount + vatAmount);
		
	}
	
	public double getBasicCharge() {
		return basicCharge;
	}
	public double getExcessCharge() {
		return excessCharge;
	}
	public double getVatCharge() {
		return vatCharge;
	}
	public double getTotal() {
		return total;
	}

	
}
