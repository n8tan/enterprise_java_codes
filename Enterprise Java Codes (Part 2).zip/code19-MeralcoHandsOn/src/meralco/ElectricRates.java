package meralco;

public interface ElectricRates {
	
	public static final double MIN_RATES = 6.20;
	public static final double MAX_RATES = 9.30;
	public static final double TAX_RATE = 0.12;
}
