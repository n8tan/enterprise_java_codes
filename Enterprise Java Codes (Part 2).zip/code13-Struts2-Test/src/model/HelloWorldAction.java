package model;



public class HelloWorldAction {

	public String execute() {
		
		return "success";
		
	}
}
