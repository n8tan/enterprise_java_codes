package test.db;

import java.sql.*;

public class TestJdbcStandAlone {

	public static void main(String[] args) {
		Connection connection = null;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			
			connection = DriverManager
					.getConnection("jdbc:mysql://localhost:3306/remante-entjav2-se31","root","");

			if (connection != null) {
				System.out.println("You made it, take control your database now!");
				
				try {
					Statement stmt = connection.createStatement();
					ResultSet rs = stmt.executeQuery("select * fRoM StuDenT");	
					System.out.println("Successful connection");
					
					while (rs.next()) {
						System.out.println(rs.getLong("studentId") + "\t" +
							rs.getString("lastName") + "\t" +
							rs.getString("firstName") + "\t"+  
							rs.getInt("yearLevel") + "\t" +
							rs.getString("course"));				
					}
					stmt.close();
				} catch (SQLException sqle) {
					System.err.println(sqle.getMessage());
				}
			} else {
				System.out.println("Failed to make connection!");
			}
		} catch (ClassNotFoundException e) {
			System.out.println("Where is your MySQL JDBC Driver?");
			e.printStackTrace();
			return;
		} catch (SQLException sqle) {
			System.err.println("SQLE - " + sqle.getMessage());
			sqle.printStackTrace();
		}
	}

}
