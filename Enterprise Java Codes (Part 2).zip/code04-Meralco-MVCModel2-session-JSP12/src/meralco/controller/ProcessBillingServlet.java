package meralco.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import meralco.model.Customer;

//2nd step - define a Servlet that will handle request

@WebServlet("/processbilling.html")
public class ProcessBillingServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {		
		int hours = Integer.parseInt(request.getParameter("hours"));
		
		if (hours < 0) {
			response.sendRedirect("index.jsp?errcode=1");
		} else {
			
				//step 3 - populate the bean
				Customer customer = new Customer();
				customer.setLastName(request.getParameter("lastName"));
				customer.setFirstName(request.getParameter("firstName"));
				
				customer.setHours(hours);
				customer.process();
				
				//step 4 - store the bean in the request, session or in servlet context
				//doing servlet chain - object binding
				request.getSession().setAttribute("meralcoCustomer", customer);
				
				//step 5 - forward the request to a JSP page
				//passing the output to another servlet
				//request.getRequestDispatcher("displaybilling.jsp").forward(request, response);
				response.sendRedirect("displaybilling.jsp");
		} 	
		}
	}
	
