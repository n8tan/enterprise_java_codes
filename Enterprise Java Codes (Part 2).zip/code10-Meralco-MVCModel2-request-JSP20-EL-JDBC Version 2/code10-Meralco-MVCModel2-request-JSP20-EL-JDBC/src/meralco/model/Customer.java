package meralco.model;

import java.sql.*;

import meralco.utility.Rates;

//1st step - define beans to represent the data
public class Customer implements Rates {

	private String lastName;
	private String firstName;
	private int hours;
	
	//computed values
	private double basicChargeAmount;
	private double excessChargeAmount;
	private double taxVatAmount;
	private double totalChargeAmount;
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public int getHours() {
		return hours;
	}
	public void setHours(int hours) {
		this.hours = hours;
	}
	public double getBasicChargeAmount() {
		return basicChargeAmount;
	}
	public void setBasicChargeAmount(double basicChargeAmount) {
		this.basicChargeAmount = basicChargeAmount;
	}
	public double getExcessChargeAmount() {
		return excessChargeAmount;
	}
	public void setExcessChargeAmount(double excessChargeAmount) {
		this.excessChargeAmount = excessChargeAmount;
	}
	public double getTaxVatAmount() {
		return taxVatAmount;
	}
	public void setTaxVatAmount(double taxVatAmount) {
		this.taxVatAmount = taxVatAmount;
	}
	public double getTotalChargeAmount() {
		return totalChargeAmount;
	}
	public void setTotalChargeAmount(double totalChargeAmount) {
		this.totalChargeAmount = totalChargeAmount;
	}
	
	private void computeBasicCharge() {
		basicChargeAmount = (hours <= LIMIT_RATE)
							? hours * BASIC_CHARGE
							: (LIMIT_RATE * BASIC_CHARGE);		
	}
	
	private void computeExcessCharge() {
		excessChargeAmount = (hours <= LIMIT_RATE)
							 ? 0
							 : (hours - LIMIT_RATE) * EXCESS_CHARGE;
	}
	
	private void computeVatAmount() {
		taxVatAmount = (basicChargeAmount + excessChargeAmount) * VAT;
	}
	
	private void computeTotalCharge() {
		setTotalChargeAmount(basicChargeAmount + excessChargeAmount + taxVatAmount);
	}
	
	private boolean recordTransaction(Connection connection) {
		try {
			String insertRecord = "Insert into MeralcoCustomer(lastName,"
				+ "firstName, hours, basicChargeAmount, excessChargeAmount,"
				+ "taxVatAmount, totalChargeAmount) values (?,?,?,?,?,?,?)";
			
			PreparedStatement ptsmt = connection.prepareStatement(insertRecord);
			ptsmt.setString(1, lastName);
			ptsmt.setString(2, firstName);
			ptsmt.setInt(3, hours);
			ptsmt.setDouble(4, basicChargeAmount);
			ptsmt.setDouble(5, excessChargeAmount);
			ptsmt.setDouble(6, taxVatAmount);
			ptsmt.setDouble(7, totalChargeAmount);
			ptsmt.executeUpdate();
			return true;
		} catch (SQLException sqle) {
			return false;
		}
	}
	
	public void process(Connection connection) { //principle of facade design pattern
		computeBasicCharge();
		computeExcessCharge();
		computeVatAmount();
		computeTotalCharge();
		recordTransaction(connection);
	}
}
