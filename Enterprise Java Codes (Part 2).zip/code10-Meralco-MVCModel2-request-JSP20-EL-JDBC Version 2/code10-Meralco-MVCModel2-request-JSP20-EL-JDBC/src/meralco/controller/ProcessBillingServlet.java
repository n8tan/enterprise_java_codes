package meralco.controller;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import meralco.model.Customer;

//2nd step - define a Servlet that will handle request
public class ProcessBillingServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	Connection connection = null;
	
	public void init(ServletConfig config) throws ServletException {
		super.init(config);
		try {
			Class.forName(config.getInitParameter("dbDriverName"));
			
			StringBuffer dbConfig = 
				new StringBuffer("jdbc:")
				.append(config.getInitParameter("dbType"))
				.append("://")
				.append(config.getInitParameter("dbServerName"))
				.append(":")
				.append(config.getInitParameter("dbPort"))
				.append("/")
				.append(config.getInitParameter("dbDatabase"));
					
			connection = DriverManager
				.getConnection(dbConfig.toString(), 
				config.getInitParameter("dbUserName"),
				config.getInitParameter("dbPassword"));
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
			return;
		} catch (SQLException sqle) {
			System.err.println("SQLE - " + sqle.getMessage());
			sqle.printStackTrace();
		}	
	}
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {		
		int hours = Integer.parseInt(request.getParameter("hoursConsumed"));
		
		if (hours < 0) {
			response.sendRedirect("index.jsp?errcode=1");
		} else {			
			//step 3 - populate the bean
			Customer customer = new Customer();
			customer.setLastName(request.getParameter("lastName"));
			customer.setFirstName(request.getParameter("firstName"));
			
			customer.setHours(hours);
			customer.process(connection);
			
			//step 4 - store the bean in the request, session or in servlet context
			request.setAttribute("meralcoCustomer", customer);
			
			//step 5 - forward the request to a JSP page
			request.getRequestDispatcher("displaybilling.jsp").forward(request, response);			
		}
	}
}
