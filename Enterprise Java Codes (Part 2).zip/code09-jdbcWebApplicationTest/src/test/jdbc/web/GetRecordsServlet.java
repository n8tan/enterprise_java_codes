package test.jdbc.web;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/index.html")
public class GetRecordsServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	Connection connection = null;

	public void init() throws ServletException {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			
			connection = DriverManager
					.getConnection("jdbc:mysql://localhost:3306/remante-entjav2-se31","root","");
		} catch (ClassNotFoundException e) {
			
			e.printStackTrace();
			return;
		} catch (SQLException sqle) {
			System.err.println("SQLE - " + sqle.getMessage());
			sqle.printStackTrace();
		}
	}

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	 
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
			
			if (connection != null) {
				System.out.println("Successful connection");
				Statement stmt = connection.createStatement();
				ResultSet studentRS = stmt.executeQuery("select * from student");
				
				request.setAttribute("dbRecord", studentRS);
				request.getRequestDispatcher("liststudents.jsp").forward(request, response);
				
			} else {
				response.sendRedirect("error.jsp");
			}
			
		} catch (SQLException sqle) {
			response.sendRedirect("error.jsp");
		}
	}

}
