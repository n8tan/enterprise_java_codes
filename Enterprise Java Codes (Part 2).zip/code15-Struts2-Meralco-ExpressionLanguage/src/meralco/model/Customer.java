package meralco.model;

import java.sql.*;

import meralco.utility.Rates;

//1st step - define beans to represent the data
public class Customer implements Rates {

	private String lastName;
	private String firstName;
	private int hours;
	
	//computed values
	private double basicChargeAmount;
	private double excessChargeAmount;
	private double taxVatAmount;
	private double totalChargeAmount;
	
	private boolean isError = false;
	public String execute() {
		computeBasicCharge();
		computeExcessCharge();
		computeVatAmount();
		computeTotalCharge();
		
		System.out.println("Last name: " + lastName);
		System.out.println("First name: " + firstName);
		System.out.println("Hours Consumed: " + hours);
		System.out.println("Basic Charge Amount: Php" + basicChargeAmount);
		System.out.println("Excess Charge Amount: Php" + excessChargeAmount);
		System.out.println("VAT Amount: Php" + taxVatAmount);
		System.out.println("Total Payable Amount: Php" + totalChargeAmount);
		
		if(isError){
			return "failure";
		}else {
			return "success";
		}
		
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		
		if(lastName.trim().length()==0){
				isError = true;
		}else {
			this.lastName = lastName;
		}
		
		System.out.println("setLastname executed.");
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		
		if(firstName.trim().length()==0){
				isError = true;
		}else {
			this.firstName = firstName;
		}
		System.out.println("setFirstName executed.");
	}
	public int getHours() {
		return hours;
	}
	public void setHours(int hours) {
		if(hours <= 0){
			isError = true;
		} else {
			this.hours = hours;
		}
		System.out.println("setHours executed.");
	}
	public double getBasicChargeAmount() {
		return basicChargeAmount;
	}
	public void setBasicChargeAmount(double basicChargeAmount) {
		this.basicChargeAmount = basicChargeAmount;
	}
	public double getExcessChargeAmount() {
		return excessChargeAmount;
	}
	public void setExcessChargeAmount(double excessChargeAmount) {
		this.excessChargeAmount = excessChargeAmount;
	}
	public double getTaxVatAmount() {
		return taxVatAmount;
	}
	public void setTaxVatAmount(double taxVatAmount) {
		this.taxVatAmount = taxVatAmount;
	}
	public double getTotalChargeAmount() {
		return totalChargeAmount;
	}
	public void setTotalChargeAmount(double totalChargeAmount) {
		this.totalChargeAmount = totalChargeAmount;
	}
	
	private void computeBasicCharge() {
		basicChargeAmount = (hours <= LIMIT_RATE)
							? hours * BASIC_CHARGE
							: (LIMIT_RATE * BASIC_CHARGE);		
	}
	
	private void computeExcessCharge() {
		excessChargeAmount = (hours <= LIMIT_RATE)
							 ? 0
							 : (hours - LIMIT_RATE) * EXCESS_CHARGE;
	}
	
	private void computeVatAmount() {
		taxVatAmount = (basicChargeAmount + excessChargeAmount) * VAT;
	}
	
	private void computeTotalCharge() {
		setTotalChargeAmount(basicChargeAmount + excessChargeAmount + taxVatAmount);
	}
	
	private boolean recordTransaction(Connection connection) {
		try {
			String insertRecord = "Insert into meralcocustomer(lastName,"
				+ "firstName, hours, basicChargeAmount, excessChargeAmount,"
				+ "taxVatAmount, totalChargeAmount) values (?,?,?,?,?,?,?)";
			
			PreparedStatement ptsmt = connection.prepareStatement(insertRecord);
			ptsmt.setString(1, lastName);
			ptsmt.setString(2, firstName);
			ptsmt.setInt(3, hours);
			ptsmt.setDouble(4, basicChargeAmount);
			ptsmt.setDouble(5, excessChargeAmount);
			ptsmt.setDouble(6, taxVatAmount);
			ptsmt.setDouble(7, totalChargeAmount);
			ptsmt.executeUpdate();
			return true;
		} catch (SQLException sqle) {
			return false;
		}
	}
	
	public Customer searchCustomer(int id, Connection connection) {
		Customer customer = new Customer();
		
		try {
			String sql = "select * from meralcocustomer where id = ?";
			
			PreparedStatement ptsmnt = connection.prepareStatement(sql);
			ptsmnt.setLong(1, id);
			
			ResultSet record = ptsmnt.executeQuery();
			
			while (record.next()) {
				customer.setLastName(record.getString("lastName"));
				customer.setFirstName(record.getString("firstName"));
				customer.setHours(record.getInt("hours"));
				customer.setBasicChargeAmount(record.getDouble("basicChargeAmount"));
				customer.setExcessChargeAmount(record.getDouble("excessChargeAmount"));
				customer.setTaxVatAmount(record.getDouble("taxVatAmount"));
				customer.setTotalChargeAmount(record.getDouble("totalChargeAmount"));
			}
		} catch (SQLException sqle) {
			sqle.printStackTrace();
		}
		return customer;
	}
	
	public void updateCustomer(Connection connection, String lastName, String firstName, int hours, double basic, double excess, double vat, double total, int id){
		try {
			String sql = "UPDATE meralcocustomer set lastName=?,firstName=?,hours=?,"
					+ "basicChargeAmount=?,excessChargeAmount=?,taxVatAmount=?,totalChargeAmount=? WHERE id=?";
			
			PreparedStatement ptsmnt = connection.prepareStatement(sql);
			ptsmnt.setString(1, lastName);
			ptsmnt.setString(2, firstName);
			ptsmnt.setInt(3, hours);
			ptsmnt.setDouble(4, basic);
			ptsmnt.setDouble(5, excess);
			ptsmnt.setDouble(6, vat);
			ptsmnt.setDouble(7, total);
			ptsmnt.setDouble(8, id);
			
			ptsmnt.executeUpdate();
			
		} catch (SQLException sqle) {
			sqle.printStackTrace();
		}
	}
	
	public void deleteRecord(Connection connection, int id){
		try {
			String sql = "delete from meralcocustomer where id=?";
			
			PreparedStatement ptsmnt = connection.prepareStatement(sql);
			ptsmnt.setInt(1, id);
			ptsmnt.executeUpdate();
			
		} catch (SQLException sqle) {
			sqle.printStackTrace();
		}
	}
	
	public void process(Connection connection) { //principle of facade design pattern
		computeBasicCharge();
		computeExcessCharge();
		computeVatAmount();
		computeTotalCharge();
		recordTransaction(connection);
	}
}
