package erdbms.controller;

import java.util.Date;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import erdbms.sample.model.Employee;

public class TestHibernate {

	public static void main(String[] args) {
		Employee employee = new Employee();

		employee.setId(1);
		employee.setLastName("Nowitzki");
		employee.setFirstName("Dirk");
		employee.setPosition("rebounding");
		employee.setDepartment("Mavericks");
		employee.setAddress("Dallas, Texas");
		employee.setJoinedDate(new Date());
		employee.setDescription("premiere power forward");
		
		 
		//open the configuration file to create a SessionFactory object
		SessionFactory sessionFactory = 
			new Configuration().configure().buildSessionFactory();
		
		Session session = sessionFactory.openSession();
		session.beginTransaction();
		session.save(employee);
		session.getTransaction().commit();
	}

}
