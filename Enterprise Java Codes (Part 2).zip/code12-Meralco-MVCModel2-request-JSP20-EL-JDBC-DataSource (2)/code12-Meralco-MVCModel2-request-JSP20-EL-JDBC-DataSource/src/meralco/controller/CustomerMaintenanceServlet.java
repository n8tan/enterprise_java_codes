package meralco.controller;

import java.io.IOException;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.sql.DataSource;

import java.sql.*;

import meralco.model.Customer;

@WebServlet("/customermaintenance.html")
public class CustomerMaintenanceServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	Connection connection;
	
	public void init(ServletConfig config) throws ServletException {
		try {			
			connection = 
				((DataSource)InitialContext.doLookup("java:/comp/env/jdbc/SE31DB"))
				.getConnection();
		} catch (NamingException ne) {
			System.err.println("NE - " + ne.getMessage());
			ne.printStackTrace();
		} catch (SQLException sqle) {
			System.err.println("SQLE - " + sqle.getMessage());
			sqle.printStackTrace();
		}	
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		int id = Integer.parseInt(request.getParameter("id"));
		String action = request.getParameter("action");
		
		try{
		if (connection != null) {
			if(action.equals("edit")){
			Customer customer = 
				new Customer().searchCustomer(id, connection);
			
			System.out.println("Last Name: " + customer.getLastName());
			
			request.setAttribute("foundCustomer", customer);
			request.setAttribute("custId", request.getParameter("id"));
			
			request.getRequestDispatcher("viewcustomer.jsp")
				.forward(request, response);
			
			} else if (action.equals("delete")){
				Customer customer = new Customer();
				customer.deleteRecord(connection, id);
				
				Statement stmt;
				stmt = connection.createStatement();
				ResultSet customerRs = stmt.executeQuery("select * fRoM meralcocustomer");
				request.setAttribute("dbRecord", customerRs);
				request.getRequestDispatcher("listcustomers.jsp")
					.forward(request, response);
				
			} else {
				response.sendRedirect("error.jsp");
			}
		} else {
			System.err.println("connection is NULL "
				+ "- CustomerMaintenanceServlet");
		}
		} catch (SQLException e){
			e.printStackTrace();
		}
	}
}
