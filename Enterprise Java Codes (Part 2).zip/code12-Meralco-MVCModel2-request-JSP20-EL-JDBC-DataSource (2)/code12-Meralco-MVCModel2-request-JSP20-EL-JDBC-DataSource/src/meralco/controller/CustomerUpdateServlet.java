package meralco.controller;

import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.sql.DataSource;

import meralco.model.Customer;

/**
 * Servlet implementation class CustomerUpdateServlet
 */
@WebServlet("/customerupdate.html")
public class CustomerUpdateServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	Connection connection;
	public void init(ServletConfig config) throws ServletException {
		try {			
			connection = 
				((DataSource)InitialContext.doLookup("java:/comp/env/jdbc/SE31DB"))
				.getConnection();
		} catch (NamingException ne) {
			System.err.println("NE - " + ne.getMessage());
			ne.printStackTrace();
		} catch (SQLException sqle) {
			System.err.println("SQLE - " + sqle.getMessage());
			sqle.printStackTrace();
		}	
	}
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String lastName = request.getParameter("lastName");
		String firstName = request.getParameter("firstName");
		int hours = Integer.parseInt(request.getParameter("hours"));
		double basicCharge = Double.parseDouble(request.getParameter("basicCharge"));
		double excessCharge = Double.parseDouble(request.getParameter("excessCharge"));
		double vatAmount = Double.parseDouble(request.getParameter("vatAmount"));
		double totalAmount = Double.parseDouble(request.getParameter("totalAmount"));
		int id = Integer.parseInt(request.getParameter("customerId"));
		
		
			try {
				
				if (connection != null) {
					Customer customer = new Customer();
					
					customer.updateCustomer(connection, lastName, firstName, hours, basicCharge, excessCharge, vatAmount, totalAmount, id);
					Statement stmt;
					stmt = connection.createStatement();
					ResultSet customerRs = stmt.executeQuery("select * fRoM meralcocustomer");
					request.setAttribute("dbRecord", customerRs);
					request.getRequestDispatcher("listcustomers.jsp")
						.forward(request, response);
				} else {
					System.err.println("connection is NULL "
						+ "- CustomerMaintenanceServlet");
				}
				
			} catch (SQLException e) {
				
				e.printStackTrace();
			}
				
		
	}

}
