package meralco.view;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import meralco.model.Customer;

@WebServlet("/displaybilling.html")
public class DisplayBillingServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.setContentType("text/html");
		
		PrintWriter out = response.getWriter();
		
		//retrieving the bound object
		Customer kustomer = (Customer) request.getAttribute("meralcoCustomer");
		
		out.print("<html>");
		out.print("<head><title>Welcome to Meralco Billing System</title></head>");
		out.print("<body>");
		out.print("<img src='images/meralco.jpg'/>");
		out.print("<h1>Welcome to Meralco Billing System</h1>");
		out.print("<p>Customer Name: <b>" + kustomer.getFirstName() + " " + 
			kustomer.getLastName() + "</b></p>");
		out.print("<p>Consumed Kilowatt Hours: <b>" + kustomer.getHours() + "</b></p>");
		out.print("Basic Charge: <b>Php" + kustomer.getBasicChargeAmount() + "</b></p>");
		out.print("Excess Charge: <b>Php" + kustomer.getExcessChargeAmount() + "</b></p>");
		out.print("VAT: <b>Php" + kustomer.getTaxVatAmount() + "</b></p>");
		out.print("Total Billing Amount: <b>Php" + kustomer.getTotalChargeAmount() + "</b></p>");
		out.print("<hr/>");
		out.print("<form action='index.html'>");
		out.print("<input type='submit' value='<< GO BACK >>'>");
		out.print("</form>");
		out.print("");
		
		out.print("</body>");
	}

}
