package meralco.utility;

public interface Rates {

	double BASIC_CHARGE = 6.20;
	double EXCESS_CHARGE = 9.30;
	
	int LIMIT_RATE = 250;
	double VAT = .12; 
}
